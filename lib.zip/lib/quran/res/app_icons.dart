class AppIcons{
  static const splashIcons='assets/quran/icons/splashIcon.png';
}