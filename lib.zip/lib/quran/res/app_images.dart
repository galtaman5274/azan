class AppImages {
  static const imageList={
    0: 'assets/quran/images/1.png',
    1: 'assets/quran/images/2.png',
    2: 'assets/quran/images/3.png',
    3: 'assets/quran/images/4.png',
    4: 'assets/quran/images/5.png',
    5: 'assets/quran/images/6.png',
    6: 'assets/quran/images/7.png',
    7: 'assets/quran/images/8.png',
    8: 'assets/quran/images/9.png',
    9: 'assets/quran/images/10.png',
    10: 'assets/quran/images/11.png',
    11: 'assets/quran/images/12.png',
    12: 'assets/quran/images/13.png',
  };
}