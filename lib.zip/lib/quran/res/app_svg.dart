class AppSvg{
  static const drawer='assets/quran/svgs/drawer.svg';
  static const loop='assets/quran/svgs/loop.svg';
  static const more='assets/quran/svgs/more.svg';
  static const next='assets/quran/svgs/next.svg';
  static const notification='assets/quran/svgs/notification.svg';
  static const pause='assets/quran/svgs/pause.svg';
  static const play='assets/quran/svgs/play.svg';
  static const prev='assets/quran/svgs/prev.svg';
  static const search='assets/quran/svgs/search.svg';
}