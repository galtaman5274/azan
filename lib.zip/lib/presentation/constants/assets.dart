class Assets {
  static const String drawerAvatarImg = 'assets/images/avatar.png';
  static const String drawerHeaderBackgroudImg =
      'assets/images/drawer_background.jpg';
}
