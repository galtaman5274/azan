import 'package:azan/app.dart';
import 'package:azan/app/prayer/prayer_notifier.dart';
import 'package:azan/presentation/localization/localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class PrayerSettingsTab extends StatefulWidget {
  PrayerSettingsTab({super.key});

  @override
  State<PrayerSettingsTab> createState() => _PrayerSettingsTabState();
}

class _PrayerSettingsTabState extends State<PrayerSettingsTab> {
  Map<String, String> prayerAdjustments = {
    'fajr': '0',
    'tulu': '0',
    'dhuhr': '0',
    'asr': '0',
    'magrib': '0',
    'isha': '0'
  };

  int num = 0;

  @override
  Widget build(BuildContext context) {
    Map<String, String> prayerAdjustmentsLocalization = {
      'fajr': context.l10n.prayerFajr,
      'tulu': context.l10n.prayerTulu,
      'dhuhr': context.l10n.prayerDhuhr,
      'asr': context.l10n.prayerAsr,
      'magrib': context.l10n.prayerMaghrib,
      'isha': context.l10n.prayerIsha
    };
    return Consumer<PrayerTimesNotifier>(
      builder: (context, provider, _) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Adjust Prayer Times (in minutes):',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            const SizedBox(height: 20),
            Column(
              children: prayerAdjustments.keys.map((prayer) {
                return Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      prayerAdjustmentsLocalization[prayer]!.toUpperCase(),
                      style: const TextStyle(fontSize: 16),
                    ),
                    SizedBox(
                      width: 180,
                      child: Row(
                        children: [
                          ElevatedButton(
                              onPressed: () {
                                setState(() {
                                  num--;
                                  prayerAdjustments[prayer] = num.toString();
                                });
                              },
                              child: const Text('-')),
                          Expanded(
                            child: TextField(
                              readOnly: true,
                              textAlign: TextAlign.center,
                              //keyboardType: TextInputType.number,
                              decoration: InputDecoration(
                                hintText: prayerAdjustments[prayer].toString(),
                              ),
                              // onChanged: (value) {
                              //   prayerAdjustments[prayer] = value;
                              // },
                            ),
                          ),
                          ElevatedButton(
                              onPressed: () {
                                setState(() {
                                  num++;
                                  prayerAdjustments[prayer] = num.toString();
                                });
                              },
                              child: const Text('+')),
                        ],
                      ),
                    ),
                  ],
                );
              }).toList(),
            ),
            const SizedBox(height: 30),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  //prayerAdjustments[prayer] = num.toString();
                  provider.saveAdjustments(prayerAdjustments);
                },
                child: const Text('Save Adjustments'),
              ),
            ),
          ],
        );
      },
    );
  }
}
