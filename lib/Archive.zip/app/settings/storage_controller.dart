import 'package:adhan/adhan.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class StorageController {
  final FlutterSecureStorage _storage;
  StorageController(this._storage);
  Future<void> saveSettings({
    required String latitude,
    required String longitude,
    required CalculationMethod calculationMethod,
    required Madhab asrMethod,
  }) async {
    await _storage.write(key: 'latitude', value: latitude.toString());
    await _storage.write(key: 'longitude', value: longitude.toString());
    await _storage.write(
        key: 'calculationMethod',
        value: CalculationMethod.values.indexOf(calculationMethod).toString());
    await _storage.write(
        key: 'asrMethod', value: Madhab.values.indexOf(asrMethod).toString());
  }

  Future<bool> checkIfSetupRequired() async {
    final results = await Future.wait([
      _storage.read(key: 'latitude'),
      _storage.read(key: 'longitude'),
      _storage.read(key: 'calculationMethod')
    ]);
    return results.any((element) => element == null);
  }

  Future<Map<String, String?>> loadSettings() async {
    final latitude = await _storage.read(key: 'latitude');
    final longitude = await _storage.read(key: 'longitude');
    final calculationMethod = await _storage.read(key: 'calculationMethod');
    final asrMethod = await _storage.read(key: 'asrMethod');

    return {
      'latitude': latitude,
      'longitude': longitude,
      'calculationMethod': calculationMethod,
      'asrMethod': asrMethod,
    };
  }
}
