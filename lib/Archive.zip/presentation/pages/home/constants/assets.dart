class Assets {
  static const String homeScreen = 'assets/images/home_1.png';
  static const String backFrame = 'assets/images/back_frame_date_508.png';
    static const String clockFrame = 'assets/images/clock_frame_v6.png';

}
